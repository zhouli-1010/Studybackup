package lambda;

public class Employee {
	
	public boolean equals(Object otherobj){
		
		
		
		
		return false;
	}

}
