package corejava;

public interface IFirstinterface {

}
