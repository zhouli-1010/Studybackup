package corejava;

public interface Name {
	
	String getName();
}
