package corejava;

public interface Collect {
	
	int size(); //An Abstract method
	
	public boolean isEmpty();

}
